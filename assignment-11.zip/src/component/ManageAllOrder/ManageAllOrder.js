import React from 'react';

const ManageAllOrder = () => {
    return (
        <div>
            Manage All Order
        </div>
    );
};

export default ManageAllOrder;