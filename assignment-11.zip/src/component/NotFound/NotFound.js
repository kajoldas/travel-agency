import React from 'react';
import notfound from './../../image/404.png'

const NotFound = () => {
    return (
        <div>
            <img src={notfound} alt="" />
        </div>
    );
};

export default NotFound;